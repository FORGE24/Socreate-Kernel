#!/usr/bin/env python3
"""Generate Socreate OS branding PNG assets from the vector logo."""

from __future__ import annotations

import math
import struct
import zlib
from pathlib import Path

BRAND = (99, 102, 241)
BRAND_DARK = (79, 70, 229)
WHITE = (255, 255, 255)
SLATE_DARK = (15, 23, 42)
SLATE_LIGHT = (248, 250, 252)

ICON_SIZES = (16, 22, 24, 32, 36, 48, 96, 256)
BOOT_SIZES = (128, 256)
FAVICON_SIZE = 32


def _clamp(value: float) -> int:
    return max(0, min(255, int(round(value))))


def _lerp(a: float, b: float, t: float) -> float:
    return a + (b - a) * t


def _blend(bg: tuple[int, int, int], fg: tuple[int, int, int], alpha: float) -> tuple[int, int, int]:
    return tuple(_clamp(_lerp(bg[i], fg[i], alpha)) for i in range(3))


def _rounded_rect_mask(x: int, y: int, size: int, radius: float) -> float:
    left = radius
    right = size - radius - 1
    top = radius
    bottom = size - radius - 1

    if left <= x <= right or top <= y <= bottom:
        inside = True
    else:
        cx = left if x < left else right
        cy = top if y < top else bottom
        inside = (x - cx) ** 2 + (y - cy) ** 2 <= radius ** 2

    if not inside:
        return 0.0

    edge = min(x, y, size - 1 - x, size - 1 - y)
    return 1.0 if edge > 1.5 else min(1.0, edge / 1.5)


def _s_path_alpha(nx: float, ny: float) -> float:
    # Stylized S built from two offset circular arcs.
    upper = math.hypot(nx - 0.58, ny - 0.34)
    lower = math.hypot(nx - 0.42, ny - 0.66)
    band = 0.0
    if 0.18 <= ny <= 0.52:
        band = max(band, 1.0 - abs(upper - 0.30) / 0.11)
    if 0.48 <= ny <= 0.82:
        band = max(band, 1.0 - abs(lower - 0.30) / 0.11)
    return max(0.0, min(1.0, band))


def render_icon(size: int) -> list[tuple[int, int, int]]:
    pixels: list[tuple[int, int, int]] = []
    radius = size * 0.22

    for y in range(size):
        for x in range(size):
            mask = _rounded_rect_mask(x, y, size, radius)
            if mask <= 0:
                pixels.append((0, 0, 0))
                continue

            t = (x + y) / max(1, (size - 1) * 2)
            bg = (
                _clamp(_lerp(BRAND[0], BRAND_DARK[0], t)),
                _clamp(_lerp(BRAND[1], BRAND_DARK[1], t)),
                _clamp(_lerp(BRAND[2], BRAND_DARK[2], t)),
            )

            nx = x / max(1, size - 1)
            ny = y / max(1, size - 1)
            s_alpha = _s_path_alpha(nx, ny) * mask
            color = _blend(bg, WHITE, min(1.0, s_alpha))
            pixels.append(color)

    return pixels


def render_banner(width: int, height: int, dark: bool) -> list[tuple[int, int, int]]:
    pixels: list[tuple[int, int, int]] = []
    bg = SLATE_DARK if dark else SLATE_LIGHT
    icon_size = height - 32

    for y in range(height):
        for x in range(width):
            color = bg
            ix = x - 24
            iy = y - 16
            if 0 <= ix < icon_size and 0 <= iy < icon_size:
                icon = render_icon(icon_size)
                color = icon[iy * icon_size + ix]
            pixels.append(color)

    return pixels


def write_png(path: Path, width: int, height: int, pixels: list[tuple[int, int, int]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    raw = bytearray()
    stride = width * 3
    for y in range(height):
        row = y * width
        raw.append(0)
        for x in range(width):
            r, g, b = pixels[row + x]
            raw.extend((r, g, b))

    def chunk(tag: bytes, data: bytes) -> bytes:
        return (
            struct.pack(">I", len(data))
            + tag
            + data
            + struct.pack(">I", zlib.crc32(tag + data) & 0xFFFFFFFF)
        )

    ihdr = struct.pack(">IIBBBBB", width, height, 8, 2, 0, 0, 0)
    png = b"\x89PNG\r\n\x1a\n"
    png += chunk(b"IHDR", ihdr)
    png += chunk(b"IDAT", zlib.compress(bytes(raw), 9))
    png += chunk(b"IEND", b"")
    path.write_bytes(png)


def render_gradient(width: int, height: int, top: tuple[int, int, int], bottom: tuple[int, int, int]) -> list[tuple[int, int, int]]:
    pixels: list[tuple[int, int, int]] = []
    for y in range(height):
        t = y / max(1, height - 1)
        row = tuple(_clamp(_lerp(top[i], bottom[i], t)) for i in range(3))
        pixels.extend([row] * width)
    return pixels


def write_assets(outdir: Path) -> None:
    for size in ICON_SIZES:
        icon = render_icon(size)
        write_png(outdir / "icons" / f"{size}x{size}" / "socreate-logo-icon.png", size, size, icon)
        write_png(outdir / "icons" / f"{size}x{size}" / "start-here.png", size, size, icon)

    for size in BOOT_SIZES:
        icon = render_icon(size)
        write_png(outdir / "bootloader" / f"bootlogo_{size}.png", size, size, icon)

    favicon = render_icon(FAVICON_SIZE)
    write_png(outdir / "favicon.png", FAVICON_SIZE, FAVICON_SIZE, favicon)
    write_png(outdir / "pixmaps" / "socreate-logo.png", 256, 256, render_icon(256))
    write_png(outdir / "pixmaps" / "socreate-logo-small.png", 48, 48, render_icon(48))

    write_png(outdir / "anaconda" / "sidebar-logo.png", 160, 160, render_icon(160))
    write_png(
        outdir / "anaconda" / "sidebar-bg.png",
        8,
        512,
        render_gradient(8, 512, SLATE_DARK, (30, 41, 59)),
    )
    write_png(
        outdir / "anaconda" / "topbar-bg.png",
        1024,
        48,
        render_gradient(1024, 48, BRAND, BRAND_DARK),
    )
    write_png(outdir / "plymouth" / "watermark.png", 256, 256, render_icon(256))


def main() -> None:
    import sys

    outdir = Path(sys.argv[1] if len(sys.argv) > 1 else "generated")
    write_assets(outdir)
    print(f"Generated Socreate logos under {outdir}")


if __name__ == "__main__":
    main()
